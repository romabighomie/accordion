$(function () {
    /* Accordion */
    $("[data-collapse]").on("click", function (event) {
        event.preventDefault();

        var blockId = $(this).data("collapse");

        $(blockId).slideToggle();
    });
})
